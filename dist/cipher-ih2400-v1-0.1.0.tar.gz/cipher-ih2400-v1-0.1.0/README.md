# cipher_ih2400_v1 

![](https://github.com/isabella808/cipher_ih2400_v1/workflows/build/badge.svg) [![codecov](https://codecov.io/gh/isabella808/cipher_ih2400_v1/branch/main/graph/badge.svg)](https://codecov.io/gh/isabella808/cipher_ih2400_v1) ![Release](https://github.com/isabella808/cipher_ih2400_v1/workflows/Release/badge.svg) [![Documentation Status](https://readthedocs.org/projects/cipher_ih2400_v1/badge/?version=latest)](https://cipher_ih2400_v1.readthedocs.io/en/latest/?badge=latest)

This project is for Homework 7 of my MDS course.

## Installation

```bash
$ pip install -i https://test.pypi.org/simple/ cipher_ih2400_v1
```

## Features

- TODO

## Dependencies

- TODO

## Usage

- TODO

## Documentation

The official documentation is hosted on Read the Docs: https://cipher_ih2400_v1.readthedocs.io/en/latest/

## Contributors

We welcome and recognize all contributions. You can see a list of current contributors in the [contributors tab](https://github.com/isabella808/cipher_ih2400_v1/graphs/contributors).

### Credits

This package was created with Cookiecutter and the UBC-MDS/cookiecutter-ubc-mds project template, modified from the [pyOpenSci/cookiecutter-pyopensci](https://github.com/pyOpenSci/cookiecutter-pyopensci) project template and the [audreyr/cookiecutter-pypackage](https://github.com/audreyr/cookiecutter-pypackage).
