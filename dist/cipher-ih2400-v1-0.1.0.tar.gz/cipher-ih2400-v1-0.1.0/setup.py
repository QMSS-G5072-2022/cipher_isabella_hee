# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['cipher_ih2400_v1']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'cipher-ih2400-v1',
    'version': '0.1.0',
    'description': 'This package is for HW7 of my MDS course.',
    'long_description': '# cipher_ih2400_v1 \n\n![](https://github.com/isabella808/cipher_ih2400_v1/workflows/build/badge.svg) [![codecov](https://codecov.io/gh/isabella808/cipher_ih2400_v1/branch/main/graph/badge.svg)](https://codecov.io/gh/isabella808/cipher_ih2400_v1) ![Release](https://github.com/isabella808/cipher_ih2400_v1/workflows/Release/badge.svg) [![Documentation Status](https://readthedocs.org/projects/cipher_ih2400_v1/badge/?version=latest)](https://cipher_ih2400_v1.readthedocs.io/en/latest/?badge=latest)\n\nThis project is for Homework 7 of my MDS course.\n\n## Installation\n\n```bash\n$ pip install -i https://test.pypi.org/simple/ cipher_ih2400_v1\n```\n\n## Features\n\n- TODO\n\n## Dependencies\n\n- TODO\n\n## Usage\n\n- TODO\n\n## Documentation\n\nThe official documentation is hosted on Read the Docs: https://cipher_ih2400_v1.readthedocs.io/en/latest/\n\n## Contributors\n\nWe welcome and recognize all contributions. You can see a list of current contributors in the [contributors tab](https://github.com/isabella808/cipher_ih2400_v1/graphs/contributors).\n\n### Credits\n\nThis package was created with Cookiecutter and the UBC-MDS/cookiecutter-ubc-mds project template, modified from the [pyOpenSci/cookiecutter-pyopensci](https://github.com/pyOpenSci/cookiecutter-pyopensci) project template and the [audreyr/cookiecutter-pypackage](https://github.com/audreyr/cookiecutter-pypackage).\n',
    'author': 'Isabella Hee',
    'author_email': 'icando2situps@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
